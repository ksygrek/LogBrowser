﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace LogBrowser
{
    /// <summary>
    /// Interaction logic for ErrorDetailsWindow.xaml
    /// </summary>
    public partial class ErrorDetailsWindow : Window
    {
        public ErrorDetailsWindow()
        {
            InitializeComponent();
        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void CopyButton_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(ErrVal.ToString());
            CopyButton.Content = "Coppied!";
        }
    }
}
