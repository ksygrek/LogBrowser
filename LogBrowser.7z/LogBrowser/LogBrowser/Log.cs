﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LogBrowser
{
    class Log
    {
        public DateTime Date { get; set; }
        public string Error { get; set; }

        public string FileName { get; set; }
    }
}
