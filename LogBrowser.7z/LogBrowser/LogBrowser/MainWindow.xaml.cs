﻿using Ookii.Dialogs.Wpf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LogBrowser
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string[] filePath = Directory.GetFiles(@"C:\");
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {
            if (IsDateSelected() == false)
                return;
            DateTime startTime = DateTime.Now;
            LogsTable.Items.Clear();
            ReadTxt2(FileSections());
            SaveButtonEnable();
            SearchTime(startTime);
        }

        private void SearchTime(DateTime start)
        {
            DateTime end = DateTime.Now;
            TimeSpan time = end.Subtract(start);
            TimeLabel.Content = $"Search time : {time.Milliseconds} Milliseconds";
        }
        private void Row_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            Log log = (Log)LogsTable.SelectedItem;
            ErrorDetailsWindow errorDetailsWindow = new ErrorDetailsWindow();
            errorDetailsWindow.Show();
            errorDetailsWindow.ErrOcur.Content = $"Error ocurred : {log.Date}";
            errorDetailsWindow.ErrVal.Text = log.Error;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            string file_name = $@"{ShowSaveFileDialog()}";
            StringBuilder strBuilder = new StringBuilder();

            for (int i = 0; i < LogsTable.Items.Count; i++)
            {
                Log log = (Log)LogsTable.Items[i];
                strBuilder.Append($"{log.Date} {log.Error} \n");
            }
            File.WriteAllText(file_name, strBuilder.ToString());

            SaveButton.Content = "Printed!";
        }
        
        public void SaveButtonEnable()
        {
            RecordsNr.Content = $"Records match : {LogsTable.Items.Count}";
            if (LogsTable.Items.Count > 0)
            {
                SaveButton.IsEnabled = true;
                SaveButton.Content = "Print";
            }
        }

        public bool IsDateSelected()
        {
            if (TimeFrom.Value == null || TimeTo.Value == null)
            {
                MessageBox.Show("Select date and time.", "Warning");
                return false;
            }
            else if(filePath.ToString() == "")
            {
                MessageBox.Show("Select folder path", "Warning");
                return false;
            }
                return true;
        }

        private int ShowMatch(string text)
        {
            Regex regex = new Regex(@"\d{2}-\d{2}-\d{4} \d{2}:\d{2}");
            Match match = regex.Match(text);
            if (match.Success)
            {
                DateTime dt = Convert.ToDateTime(match.Value);
                var x = DateCompare(dt);
                if (x == 1)
                    return 1;
                else if (x == -1)
                    return -1;
                else
                    return 0;
            }
            else
                return 2;
        }

        public int DateCompare(DateTime date)
        {
            if (date < Convert.ToDateTime(TimeFrom.Value))
                return -1;
            else if (date > Convert.ToDateTime(TimeTo.Value))
                return 0;
            else
                return 1;
        }

        private int FileLength(string path)
        {
            int len = 0;
            using (FileStream fs = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (BufferedStream bs = new BufferedStream(fs))
            using (StreamReader sr = new StreamReader(bs))
            {
                
                while (sr.ReadLine() != null) { len++; }
            }
            return len;
        }

        private List<int> FileSections()
        {
            List<int> sections = new List<int>();
            //var filePath = Directory.GetFiles(@"C:\Users\kbielec\Downloads\2021_06_28_logs\", "*.txt");
            int sectionLength = 5000;
            

            foreach (var file in filePath)
            {
                
                int linesNr = FileLength(file);
                using (FileStream fs = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (BufferedStream bs = new BufferedStream(fs))
                using (StreamReader sr = new StreamReader(bs))
                {
                    string line;
                    

                    int skipTo = 0;
                    for (int i = 0; i < linesNr; i++)
                    {
                        if(i < skipTo)
                        {
                            sr.ReadLine();
                            continue;
                        }
                        
                        int lev = 0;
                        line = sr.ReadLine();
                        if (line != "" || line != null)
                            lev = ShowMatch(line);
                        else
                            continue;

                        //0 - too late
                        //1 - ok
                        //2 - log continue
                        //-1 - too earlie
                        switch (lev)
                        {
                            case 0:
                                continue;
                            case 1:
                                sections.Add(1);
                                skipTo = skipTo + sectionLength;
                                //if (skipTo > linesNr)
                                //    skipTo = linesNr - 10;
                                break;
                            case 2:
                                break;
                            case -1:
                                skipTo = skipTo + sectionLength;
                                //if (skipTo > linesNr)
                                //    skipTo = linesNr - 10;
                                sections.Add(0);
                                break;
                        }
                    }
                    return sections;
                }
            }
            return sections;
        }

        public void ReadTxt2(List<int> sections)
        {
            //FileSections();
            int firstRecordToCheck = 0;
            for(int i = 0; i < sections.Count; i++)
            {
                if (sections[i] == 0)
                    firstRecordToCheck++;
            }
            firstRecordToCheck = firstRecordToCheck * 5000;

            //var filePath = Directory.GetFiles(@"C:\Users\kbielec\Downloads\2021_06_28_logs\", "*.txt");
            Log currentLog = new Log();
            int last = 0;

            foreach (var file in filePath)
            {
                using (FileStream fs = File.Open(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (BufferedStream bs = new BufferedStream(fs))
                using (StreamReader sr = new StreamReader(bs))
                {
                    string line;
                    int i = 0;
                    while ((line = sr.ReadLine()) != null)
                    {
                        if (i < firstRecordToCheck)
                        {
                            i++;
                            continue;
                        }

                        if (line.Length == 0)
                            continue;
                        int lev = 0;
                        lev = ShowMatch(line);
                        Log log = new Log();
                        switch (lev)
                        {
                            case 1:
                                if(last == 1)
                                    LogsTable.Items.Add(currentLog);
                                last = 0;
                                log.Date = DateTime.Parse(line.Substring(0, 19));
                                log.Error = line.Substring(20);
                                log.FileName = fs.Name;
                                currentLog = log;
                                break;
                            case 2:
                                log.Date = currentLog.Date;
                                log.Error = $"{currentLog.Error} \n{line}";
                                log.FileName = fs.Name;
                                currentLog.Error = log.Error;
                                last = 1;
                                continue;
                            case 0:
                                return;
                            case -1:
                                continue;
                        }
                        LogsTable.Items.Add(log);
                    }
                }
            }
        }

        private void FileDialog_Click(object sender, RoutedEventArgs e)
        {
            filePath = Directory.GetFiles($@"{ShowFolderBrowserDialog()}");
        }
        private string ShowFolderBrowserDialog()
        {
            VistaFolderBrowserDialog dialog = new VistaFolderBrowserDialog();
            dialog.Description = "Please select a folder.";
            dialog.UseDescriptionForTitle = true;
            dialog.ShowDialog(this);
            Search.IsEnabled = true;
            return dialog.SelectedPath;
        }
        private string ShowSaveFileDialog()
        {
            VistaSaveFileDialog dialog = new VistaSaveFileDialog();
            dialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            dialog.DefaultExt = "txt";
            dialog.ShowDialog(this);
            //    MessageBox.Show(this, "The selected file was: " + dialog.FileName, "Sample save file dialog");
            return dialog.FileName;
        }
    }
}
